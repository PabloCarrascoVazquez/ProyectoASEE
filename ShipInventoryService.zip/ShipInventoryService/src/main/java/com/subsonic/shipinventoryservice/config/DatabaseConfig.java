package com.subsonic.shipinventoryservice.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

@Configuration
public class DatabaseConfig {
    private static final Logger log = LoggerFactory.getLogger(DatabaseConfig.class);

    @Value("${db.engine:sqlite}")
    private String dbEngine;

    @Value("${sqlite.db.path:shipinventory.db}")
    private String sqliteDbPath;

    @Value("${db.host:127.0.0.1}")
    private String dbHost;

    @Value("${db.port:5432}")
    private int dbPort;

    @Value("${db.name:shipinventory_db}")
    private String dbName;

    @Value("${db.user:postgres}")
    private String dbUser;

    @Value("${db.password:}")
    private String dbPassword;

    @Bean
    @Primary
    public DataSource dataSource() {
        String engine = (dbEngine != null ? dbEngine.trim().toLowerCase() : "sqlite");
        HikariConfig config = new HikariConfig();

        if ("postgres".equals(engine)) {
            log.info("Configurando DataSource PostgreSQL hacia {}:{}/{}", dbHost, dbPort, dbName);
            config.setDriverClassName("org.postgresql.Driver");
            config.setJdbcUrl("jdbc:postgresql://" + dbHost + ":" + dbPort + "/" + dbName);
            config.setUsername(dbUser);
            config.setPassword(dbPassword);
            config.setMaximumPoolSize(10);
            config.setMinimumIdle(2);
            config.setPoolName("Postgres-ShipInventoryPool");
        } else {
            log.info("Configurando DataSource SQLite hacia {}", sqliteDbPath);
            config.setDriverClassName("org.sqlite.JDBC");
            config.setJdbcUrl("jdbc:sqlite:" + sqliteDbPath);
            config.setMaximumPoolSize(5);
            config.setPoolName("SQLite-ShipInventoryPool");
            config.setConnectionInitSql("PRAGMA foreign_keys = ON;");
        }

        HikariDataSource ds = new HikariDataSource(config);
        initializeSchema(ds, engine);
        return ds;
    }

    private void initializeSchema(DataSource ds, String engine) {
        try (Connection conn = ds.getConnection();
             Statement stmt = conn.createStatement()) {

            if ("postgres".equals(engine)) {
                log.info("Inicializando/verificando tablas en base de datos PostgreSQL...");

                stmt.execute("""
                    CREATE TABLE IF NOT EXISTS stock_productos (
                        id_producto VARCHAR(36) PRIMARY KEY,
                        nombre_producto VARCHAR(200) NOT NULL,
                        variante VARCHAR(100),
                        unidades_disponibles INT NOT NULL DEFAULT 0,
                        unidades_bloqueadas INT NOT NULL DEFAULT 0,
                        precio DECIMAL(10, 2) NOT NULL,
                        ubicacion_almacen VARCHAR(200),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );
                """);
                stmt.execute("CREATE INDEX IF NOT EXISTS idx_nombre ON stock_productos (nombre_producto);");

                stmt.execute("""
                    CREATE TABLE IF NOT EXISTS envios (
                        id_envio VARCHAR(36) PRIMARY KEY,
                        id_pedido VARCHAR(36) NOT NULL,
                        estado_envio VARCHAR(30) NOT NULL DEFAULT 'Pendiente',
                        empresa_transporte VARCHAR(100),
                        tracking_number VARCHAR(100),
                        direccion_entrega VARCHAR(500),
                        notas_incidencia TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );
                """);
                stmt.execute("CREATE INDEX IF NOT EXISTS idx_pedido ON envios (id_pedido);");
                stmt.execute("CREATE INDEX IF NOT EXISTS idx_estado ON envios (estado_envio);");

            } else {
                log.info("Inicializando/verificando tablas en base de datos SQLite...");
                stmt.execute("PRAGMA foreign_keys = ON;");

                stmt.execute("""
                    CREATE TABLE IF NOT EXISTS stock_productos (
                        id_producto VARCHAR(36) PRIMARY KEY,
                        nombre_producto VARCHAR(200) NOT NULL,
                        variante VARCHAR(100),
                        unidades_disponibles INT NOT NULL DEFAULT 0,
                        unidades_bloqueadas INT NOT NULL DEFAULT 0,
                        precio DECIMAL(10, 2) NOT NULL,
                        ubicacion_almacen VARCHAR(200),
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                    );
                """);

                stmt.execute("""
                    CREATE TABLE IF NOT EXISTS envios (
                        id_envio VARCHAR(36) PRIMARY KEY,
                        id_pedido VARCHAR(36) NOT NULL,
                        estado_envio VARCHAR(30) NOT NULL DEFAULT 'Pendiente',
                        empresa_transporte VARCHAR(100),
                        tracking_number VARCHAR(100),
                        direccion_entrega VARCHAR(500),
                        notas_incidencia TEXT,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                    );
                """);
            }

            // Poblado de datos iniciales / semilla (se ejecuta si las tablas están vacías)
            seedSampleDataIfEmpty(stmt);

            log.info("Esquema y datos semilla de base de datos verificados e inicializados correctamente.");
        } catch (Exception e) {
            log.error("Error al inicializar las tablas de la base de datos: {}", e.getMessage(), e);
        }
    }

    private void seedSampleDataIfEmpty(Statement stmt) {
        try {
            Integer countStock = null;
            try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM stock_productos")) {
                if (rs.next()) {
                    countStock = rs.getInt(1);
                }
            } catch (Exception ignored) {}

            if (countStock != null && countStock == 0) {
                stmt.execute("""
                    INSERT INTO stock_productos
                        (id_producto, nombre_producto, variante, unidades_disponibles, unidades_bloqueadas, precio, ubicacion_almacen)
                    VALUES
                        ('prod-001', 'Camiseta Oficial Subsonic', 'Talla L - Negra', 150, 0, 25.50, 'Pasillo B - Estante 4'),
                        ('prod-002', 'Gorra Subsonic 2026', 'Talla única', 80, 0, 18.00, 'Pasillo A - Estante 1'),
                        ('prod-003', 'Tote Bag Subsonic', 'Azul', 200, 0, 12.00, 'Pasillo C - Estante 2'),
                        ('p1234567-e89b-12d3-a456-426614174000', 'Camiseta Oficial Subsonic', 'Talla L - Negra', 150, 0, 25.50, 'Pasillo B - Estante 4');
                """);
                log.info("Datos semilla de stock insertados correctamente.");
            }

            Integer countEnvios = null;
            try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM envios")) {
                if (rs.next()) {
                    countEnvios = rs.getInt(1);
                }
            } catch (Exception ignored) {}

            if (countEnvios != null && countEnvios == 0) {
                stmt.execute("""
                    INSERT INTO envios
                        (id_envio, id_pedido, estado_envio, empresa_transporte, tracking_number, direccion_entrega)
                    VALUES
                        ('env-001', 'ped-10293847', 'Pendiente', 'Correos Express', NULL, 'Calle Mayor 123, 28080 Madrid'),
                        ('e9876543-e89b-12d3-a456-426614174111', 'ped-10293847', 'Pendiente', 'Correos Express', NULL, 'Calle Falsa 123, 28080 Madrid');
                """);
                log.info("Datos semilla de envíos insertados correctamente.");
            }
        } catch (Exception e) {
            log.warn("Aviso al intentar insertar datos semilla: {}", e.getMessage());
        }
    }

    @Bean
    @Primary
    public JdbcTemplate appJdbcTemplate(DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean
    public PlatformTransactionManager transactionManager(DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }
}
